# InitOrder

`deploy_init_hints.sh`

Will drop in replacement init scripts, helping you to see what init scripts are used during different conditions, and in what order
It is not adviced to use on a "real" FS, since there will be a lot of cleanup to be done.
Better suited for a temp FS

